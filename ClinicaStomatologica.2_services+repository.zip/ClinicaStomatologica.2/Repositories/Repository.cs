using ClinicaStomatologica.Data;
using ClinicaStomatologica.Models;
using Microsoft.EntityFrameworkCore;

namespace ClinicaStomatologica.Repositories;

public class Repository<T> : IRepository<T> where T : class
{
    protected readonly ClinicaContext _context;
    private readonly DbSet<T> _dbSet;

    public Repository(ClinicaContext context)
    {
        _context = context;
        _dbSet = _context.Set<T>();
    }

    public async Task<IEnumerable<T>> GetAllAsync() => await _dbSet.ToListAsync();
    public async Task<T> GetByIdAsync(int id) => await _dbSet.FindAsync(id);
    public async Task AddAsync(T entity) => await _dbSet.AddAsync(entity);
    public void Update(T entity) => _dbSet.Update(entity);
    public void Delete(T entity) => _dbSet.Remove(entity);
    public async Task SaveAsync() => await _context.SaveChangesAsync();
    public async Task<IEnumerable<Programare>> GetAllWithDetailsAsync()
    {
        return await _context.Programari
            .Include(p => p.Pacient)
            .Include(p => p.Medic)
            .ToListAsync();
    }
}