﻿using Microsoft.EntityFrameworkCore;
using ClinicaStomatologica.Data;
using ClinicaStomatologica.Repositories;
using ClinicaStomatologica.Services;

var builder = WebApplication.CreateBuilder(args);

//  Adaugă suportul pentru MVC
builder.Services.AddControllersWithViews();

//Conectează Baza de Date
builder.Services.AddDbContext<ClinicaContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

//  ÎNREGISTRARE REPOSITORY 
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

// ÎNREGISTRARE SERVICII (Cerința: Business Logic)
builder.Services.AddScoped<IPacientService, PacientService>();
builder.Services.AddScoped<IMedicService, MedicService>();
builder.Services.AddScoped<IProgramareService, ProgramareService>();

var app = builder.Build();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Configurarea rutei și a fișierelor statice
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage(); // Aceasta ne va arăta eroarea reală în browser în loc de eroarea 500
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();



app.Run();