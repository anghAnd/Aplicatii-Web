﻿using ClinicaStomatologica.Models;
using ClinicaStomatologica.Repositories;

namespace ClinicaStomatologica.Services
{
    public class ProgramareService : IProgramareService
    {
        private readonly IRepository<Programare> _repo;

        public ProgramareService(IRepository<Programare> repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<Programare>> GetAllAsync()
        {
            return await (_repo as Repository<Programare>).GetAllWithDetailsAsync();
        }

        public async Task<Programare?> GetByIdAsync(int id)
        {
            return await _repo.GetByIdAsync(id);
        }

        public async Task CreateAsync(Programare p)
        {
            // Aici poți adăuga logică de business (ex: verificare dacă medicul e disponibil)
            await _repo.AddAsync(p);
            await _repo.SaveAsync();
        }

        public async Task UpdateAsync(Programare p)
        {
            _repo.Update(p);
            await _repo.SaveAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var programare = await _repo.GetByIdAsync(id);
            if (programare != null)
            {
                _repo.Delete(programare);
                await _repo.SaveAsync();
            }
        }
    }
}