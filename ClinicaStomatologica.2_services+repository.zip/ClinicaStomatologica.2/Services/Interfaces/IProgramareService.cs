using ClinicaStomatologica.Models;

namespace ClinicaStomatologica.Services
{
	public interface IProgramareService
	{
		Task<IEnumerable<Programare>> GetAllAsync();
		Task<Programare?> GetByIdAsync(int id);
		Task CreateAsync(Programare p);
		Task UpdateAsync(Programare p);
		Task DeleteAsync(int id);
	}
}