using ClinicaStomatologica.Models;
namespace ClinicaStomatologica.Services;

public interface IMedicService
{
    Task<IEnumerable<Medic>> GetAllAsync();
    Task<Medic> GetByIdAsync(int id);
    Task CreateAsync(Medic m);
    Task UpdateAsync(Medic m);
    Task DeleteAsync(int id);
}