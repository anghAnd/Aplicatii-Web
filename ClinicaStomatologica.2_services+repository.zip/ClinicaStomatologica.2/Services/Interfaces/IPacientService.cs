﻿using ClinicaStomatologica.Models;

namespace ClinicaStomatologica.Services
{
    public interface IPacientService
    {
        Task<IEnumerable<Pacient>> GetAllAsync();
        Task<Pacient> GetByIdAsync(int id);
        Task CreateAsync(Pacient p);
        Task UpdateAsync(Pacient p);
        Task DeleteAsync(int id);
    }
}