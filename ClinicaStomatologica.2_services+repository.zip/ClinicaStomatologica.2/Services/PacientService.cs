﻿using ClinicaStomatologica.Models;
using ClinicaStomatologica.Repositories;

namespace ClinicaStomatologica.Services
{
    public class PacientService : IPacientService
    {
        private readonly IRepository<Pacient> _repo;

        public PacientService(IRepository<Pacient> repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<Pacient>> GetAllAsync() => await _repo.GetAllAsync();

        public async Task<Pacient> GetByIdAsync(int id) => await _repo.GetByIdAsync(id);

        public async Task CreateAsync(Pacient p)
        {
            await _repo.AddAsync(p);
            await _repo.SaveAsync();
        }

        public async Task UpdateAsync(Pacient p)
        {
            _repo.Update(p);
            await _repo.SaveAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var p = await _repo.GetByIdAsync(id);
            if (p != null)
            {
                _repo.Delete(p);
                await _repo.SaveAsync();
            }
        }
    } // Închide Clasa
} // Închide Namespace