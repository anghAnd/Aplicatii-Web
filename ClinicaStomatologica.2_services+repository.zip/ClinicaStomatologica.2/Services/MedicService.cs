using ClinicaStomatologica.Models;
using ClinicaStomatologica.Repositories;

namespace ClinicaStomatologica.Services
{
    public class MedicService : IMedicService
    {
        private readonly IRepository<Medic> _repo;
        public MedicService(IRepository<Medic> repo) => _repo = repo;

        public async Task<IEnumerable<Medic>> GetAllAsync() => await _repo.GetAllAsync();
        public async Task<Medic> GetByIdAsync(int id) => await _repo.GetByIdAsync(id);
        public async Task CreateAsync(Medic m) { await _repo.AddAsync(m); await _repo.SaveAsync(); }
        public async Task UpdateAsync(Medic m) { _repo.Update(m); await _repo.SaveAsync(); }
        public async Task DeleteAsync(int id)
        {
            var m = await _repo.GetByIdAsync(id);
            if (m != null) { _repo.Delete(m); await _repo.SaveAsync(); }
        }
    }
}