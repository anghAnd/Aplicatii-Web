﻿using Microsoft.AspNetCore.Mvc;
using ClinicaStomatologica.Models;
using ClinicaStomatologica.Services;

namespace ClinicaStomatologica.Controllers
{
    public class PacientiController : Controller
    {
        private readonly IPacientService _service;

        public PacientiController(IPacientService service)
        {
            _service = service;
        }

        // Adăugăm un try-catch aici să vedem dacă lista de pacienți are probleme
        public async Task<IActionResult> Index()
        {
            var pacienti = await _service.GetAllAsync();
            return View(pacienti);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Pacient p)
        {
            if (ModelState.IsValid) // Verifică dacă toate câmpurile obligatorii (ex: CNP) sunt completate
            {
                await _service.CreateAsync(p);
                return RedirectToAction(nameof(Index)); // Te trimite înapoi la tabel după salvare
            }
            return View(p); // Dacă sunt erori, rămâne pe pagină și le afișează
        }

        //  Deshide pagina de editare cu datele existente
        public async Task<IActionResult> Edit(int id)
        {
            var p = await _service.GetByIdAsync(id);
            if (p == null) return NotFound();
            return View(p);
        }

        //  Salvează modificările efectuate
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Pacient p)
        {
            if (ModelState.IsValid)
            {
                await _service.UpdateAsync(p);
                return RedirectToAction(nameof(Index));
            }
            return View(p);
        }

        // Afișează pagina de confirmare a ștergerii
        public async Task<IActionResult> Delete(int id)
        {
            var p = await _service.GetByIdAsync(id);
            if (p == null) return NotFound();
            return View(p);
        }

        // Execută ștergerea propriu-zisă după confirmare
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _service.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
      
    }
}