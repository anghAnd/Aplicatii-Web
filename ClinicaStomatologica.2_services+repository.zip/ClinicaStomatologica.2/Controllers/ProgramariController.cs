﻿using Microsoft.AspNetCore.Mvc;
using ClinicaStomatologica.Models;
using ClinicaStomatologica.Services;

namespace ClinicaStomatologica.Controllers
{
    public class ProgramariController : Controller
    {
        // Folosim interfețele serviciilor pentru decuplare
        private readonly IProgramareService _programareService;
        private readonly IPacientService _pacientService;
        private readonly IMedicService _medicService;

        public ProgramariController(
            IProgramareService programareService, 
            IPacientService pacientService, 
            IMedicService medicService)
        {
            _programareService = programareService;
            _pacientService = pacientService;
            _medicService = medicService;
        }

        // Afișare listă
        public async Task<IActionResult> Index()
        {
            // GetAllAsync din ProgramareService ar trebui să returneze și datele Medicului/Pacientului
            var lista = await _programareService.GetAllAsync();
            return View(lista);
        }

        // Formular adăugare
        public async Task<IActionResult> Create()
        {
            ViewBag.Pacienti = await _pacientService.GetAllAsync();
            ViewBag.Medici = await _medicService.GetAllAsync();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Programare p)
        {
            // Curățăm validarea pentru obiectele de navigare
            ModelState.Remove("Pacient");
            ModelState.Remove("Medic");

            if (ModelState.IsValid)
            {
                await _programareService.CreateAsync(p);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Pacienti = await _pacientService.GetAllAsync();
            ViewBag.Medici = await _medicService.GetAllAsync();
            return View(p);
        }

        // Formular editare
        public async Task<IActionResult> Edit(int id)
        {
            var p = await _programareService.GetByIdAsync(id);
            if (p == null) return NotFound();

            ViewBag.Pacienti = await _pacientService.GetAllAsync();
            ViewBag.Medici = await _medicService.GetAllAsync();
            return View(p);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Programare p)
        {
            ModelState.Remove("Pacient");
            ModelState.Remove("Medic");

            if (ModelState.IsValid)
            {
                await _programareService.UpdateAsync(p);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Pacienti = await _pacientService.GetAllAsync();
            ViewBag.Medici = await _medicService.GetAllAsync();
            return View(p);
        }

        // Ștergere
        public async Task<IActionResult> Delete(int id)
        {
            var p = await _programareService.GetByIdAsync(id);
            if (p == null) return NotFound();
            return View(p);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _programareService.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}