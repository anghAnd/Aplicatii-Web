﻿using Microsoft.AspNetCore.Mvc;
using ClinicaStomatologica.Services;
using ClinicaStomatologica.Models;

namespace ClinicaStomatologica.Controllers
{
    public class MediciController : Controller
    {
        private readonly IMedicService _service;

        public MediciController(IMedicService service) => _service = service;

        public async Task<IActionResult> Index() => View(await _service.GetAllAsync());

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(Medic m)
        {
            await _service.CreateAsync(m);
            return RedirectToAction(nameof(Index));
        }

       
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var medic = await _service.GetByIdAsync(id);
            if (medic == null) return NotFound();
            return View(medic);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Medic m)
        {
            ModelState.Remove("Programari");

            if (ModelState.IsValid)
            {
                await _service.UpdateAsync(m);
                return RedirectToAction(nameof(Index));
            }
            return View(m);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var p = await _service.GetByIdAsync(id);
            if (p == null) return NotFound();
            return View(p);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _service.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}