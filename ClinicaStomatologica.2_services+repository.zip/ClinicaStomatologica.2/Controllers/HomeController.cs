﻿using Microsoft.AspNetCore.Mvc;

namespace ClinicaStomatologica.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
