﻿INSERT INTO dbo.Pacienti (Nume, Prenume, CNP, Telefon, Email, DataNasterii)
VALUES ('Popa', 'Andrei', '1234567890123', '0712345678', 'andrei@example.com', '1990-05-20');
