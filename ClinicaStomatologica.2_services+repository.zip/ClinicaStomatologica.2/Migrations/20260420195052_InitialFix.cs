﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClinicaStomatologica.Migrations
{
    /// <inheritdoc />
    public partial class InitialFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Programari_Medici_IdMedic",
                table: "Programari");

            migrationBuilder.DropForeignKey(
                name: "FK_Programari_Pacienti_IdPacient",
                table: "Programari");

            migrationBuilder.AddForeignKey(
                name: "FK_Programari_Medici_IdMedic",
                table: "Programari",
                column: "IdMedic",
                principalTable: "Medici",
                principalColumn: "IdMedic",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Programari_Pacienti_IdPacient",
                table: "Programari",
                column: "IdPacient",
                principalTable: "Pacienti",
                principalColumn: "IdPacient",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Programari_Medici_IdMedic",
                table: "Programari");

            migrationBuilder.DropForeignKey(
                name: "FK_Programari_Pacienti_IdPacient",
                table: "Programari");

            migrationBuilder.AddForeignKey(
                name: "FK_Programari_Medici_IdMedic",
                table: "Programari",
                column: "IdMedic",
                principalTable: "Medici",
                principalColumn: "IdMedic",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Programari_Pacienti_IdPacient",
                table: "Programari",
                column: "IdPacient",
                principalTable: "Pacienti",
                principalColumn: "IdPacient",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
