﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClinicaStomatologica.Migrations
{
    /// <inheritdoc />
    public partial class FixProgramareFK : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
