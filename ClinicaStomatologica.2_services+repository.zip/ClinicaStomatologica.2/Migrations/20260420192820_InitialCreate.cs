﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClinicaStomatologica.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Medici",
                columns: table => new
                {
                    IdMedic = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prenume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Specializare = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Telefon = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FotoPath = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Medici", x => x.IdMedic);
                });

            migrationBuilder.CreateTable(
                name: "Pacienti",
                columns: table => new
                {
                    IdPacient = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prenume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CNP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Telefon = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DataNasterii = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pacienti", x => x.IdPacient);
                });

            migrationBuilder.CreateTable(
                name: "Servicii",
                columns: table => new
                {
                    IdServiciu = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Denumire = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pret = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Durata = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Servicii", x => x.IdServiciu);
                });

            migrationBuilder.CreateTable(
                name: "Programari",
                columns: table => new
                {
                    IdProgramare = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdPacient = table.Column<int>(type: "int", nullable: false),
                    IdMedic = table.Column<int>(type: "int", nullable: false),
                    DataProgramare = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MedicIdMedic = table.Column<int>(type: "int", nullable: true),
                    PacientIdPacient = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Programari", x => x.IdProgramare);
                    table.ForeignKey(
                        name: "FK_Programari_Medici_IdMedic",
                        column: x => x.IdMedic,
                        principalTable: "Medici",
                        principalColumn: "IdMedic",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Programari_Medici_MedicIdMedic",
                        column: x => x.MedicIdMedic,
                        principalTable: "Medici",
                        principalColumn: "IdMedic");
                    table.ForeignKey(
                        name: "FK_Programari_Pacienti_IdPacient",
                        column: x => x.IdPacient,
                        principalTable: "Pacienti",
                        principalColumn: "IdPacient",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Programari_Pacienti_PacientIdPacient",
                        column: x => x.PacientIdPacient,
                        principalTable: "Pacienti",
                        principalColumn: "IdPacient");
                });

            migrationBuilder.CreateTable(
                name: "Facturi",
                columns: table => new
                {
                    IdFactura = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdProgramare = table.Column<int>(type: "int", nullable: false),
                    DataEmitere = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TotalPlata = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Facturi", x => x.IdFactura);
                    table.ForeignKey(
                        name: "FK_Facturi_Programari_IdProgramare",
                        column: x => x.IdProgramare,
                        principalTable: "Programari",
                        principalColumn: "IdProgramare",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tratamente",
                columns: table => new
                {
                    IdTratament = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdProgramare = table.Column<int>(type: "int", nullable: false),
                    ProgramareIdProgramare = table.Column<int>(type: "int", nullable: false),
                    IdServiciu = table.Column<int>(type: "int", nullable: false),
                    ServiciuIdServiciu = table.Column<int>(type: "int", nullable: false),
                    Observatii = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tratamente", x => x.IdTratament);
                    table.ForeignKey(
                        name: "FK_Tratamente_Programari_ProgramareIdProgramare",
                        column: x => x.ProgramareIdProgramare,
                        principalTable: "Programari",
                        principalColumn: "IdProgramare",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Tratamente_Servicii_ServiciuIdServiciu",
                        column: x => x.ServiciuIdServiciu,
                        principalTable: "Servicii",
                        principalColumn: "IdServiciu",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Facturi_IdProgramare",
                table: "Facturi",
                column: "IdProgramare",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Programari_IdMedic",
                table: "Programari",
                column: "IdMedic");

            migrationBuilder.CreateIndex(
                name: "IX_Programari_IdPacient",
                table: "Programari",
                column: "IdPacient");

            migrationBuilder.CreateIndex(
                name: "IX_Programari_MedicIdMedic",
                table: "Programari",
                column: "MedicIdMedic");

            migrationBuilder.CreateIndex(
                name: "IX_Programari_PacientIdPacient",
                table: "Programari",
                column: "PacientIdPacient");

            migrationBuilder.CreateIndex(
                name: "IX_Tratamente_ProgramareIdProgramare",
                table: "Tratamente",
                column: "ProgramareIdProgramare");

            migrationBuilder.CreateIndex(
                name: "IX_Tratamente_ServiciuIdServiciu",
                table: "Tratamente",
                column: "ServiciuIdServiciu");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Facturi");

            migrationBuilder.DropTable(
                name: "Tratamente");

            migrationBuilder.DropTable(
                name: "Programari");

            migrationBuilder.DropTable(
                name: "Servicii");

            migrationBuilder.DropTable(
                name: "Medici");

            migrationBuilder.DropTable(
                name: "Pacienti");
        }
    }
}
