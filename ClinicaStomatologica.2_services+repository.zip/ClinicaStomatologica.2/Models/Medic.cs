﻿using System.ComponentModel.DataAnnotations;

namespace ClinicaStomatologica.Models;

public class Medic
{
    [Key]
    public int IdMedic { get; set; }
    public string Nume { get; set; }
    public string Prenume { get; set; }
    public string Specializare { get; set; }
    public string Telefon { get; set; }
    public string? Email { get; set; }
    
    public string? FotoPath { get; set; }

    public ICollection<Programare>? Programari { get; set; }
}