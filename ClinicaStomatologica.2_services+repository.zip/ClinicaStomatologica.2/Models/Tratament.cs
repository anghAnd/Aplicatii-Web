﻿using System.ComponentModel.DataAnnotations;

namespace ClinicaStomatologica.Models;

public class Tratament
{
    [Key]
    public int IdTratament { get; set; }

    public int IdProgramare { get; set; }
    public Programare Programare { get; set; }

    public int IdServiciu { get; set; }
    public Serviciu Serviciu { get; set; }

    public string Observatii { get; set; }
}