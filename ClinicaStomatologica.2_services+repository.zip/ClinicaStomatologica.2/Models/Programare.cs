﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClinicaStomatologica.Models;
public class Programare
{
    [Key]
    public int IdProgramare { get; set; } // PK implicit
    public int IdPacient { get; set; }
    [ForeignKey("IdPacient")]
    public virtual Pacient? Pacient { get; set; }
    public int IdMedic { get; set; }
    [ForeignKey("IdMedic")]
    public virtual Medic? Medic { get; set; }
    public DateTime DataProgramare { get; set; }
    public string? Status { get; set; }
    public ICollection<Tratament>? Tratamente { get; set; }
    public virtual Factura? Factura { get; set; } 
}