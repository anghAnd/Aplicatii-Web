﻿using System.ComponentModel.DataAnnotations;

namespace ClinicaStomatologica.Models;
public class Pacient
{
    [Key] 
    public int IdPacient { get; set; }

    public string Nume { get; set; } = string.Empty;
    public string Prenume { get; set; } = string.Empty;

   
    public string? CNP { get; set; }
    public string? Telefon { get; set; }
    public string? Email { get; set; }

    public DateTime? DataNasterii { get; set; } // "?" îl face opțional

    public ICollection<Programare>? Programari { get; set; }
}