﻿using System.ComponentModel.DataAnnotations; 
namespace ClinicaStomatologica.Models;

public class Factura
{
    [Key] 
    public int IdFactura { get; set; }

    public int IdProgramare { get; set; }
    public Programare Programare { get; set; }

    public DateTime DataEmitere { get; set; }
    public decimal TotalPlata { get; set; }
}