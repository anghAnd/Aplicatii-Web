﻿using System.ComponentModel.DataAnnotations;

namespace ClinicaStomatologica.Models;

public class Serviciu
{
    [Key]
    public int IdServiciu { get; set; }
    public string Denumire { get; set; }
    public decimal Pret { get; set; }
    public int Durata { get; set; }

    public ICollection<Tratament> Tratamente { get; set; }
}