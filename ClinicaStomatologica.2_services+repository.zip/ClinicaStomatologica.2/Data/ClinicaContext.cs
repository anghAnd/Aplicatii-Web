﻿using Microsoft.EntityFrameworkCore;
using ClinicaStomatologica.Models;

namespace ClinicaStomatologica.Data;

public class ClinicaContext : DbContext
{
    public ClinicaContext(DbContextOptions<ClinicaContext> options) : base(options) { }

    public DbSet<Programare> Programari { get; set; }
    public DbSet<Factura> Facturi { get; set; }
    public DbSet<Pacient> Pacienti { get; set; }
    public DbSet<Medic> Medici { get; set; }
    public DbSet<Tratament> Tratamente { get; set; }
    public DbSet<Serviciu> Servicii { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Configurări Chei Primare
        modelBuilder.Entity<Factura>().HasKey(f => f.IdFactura);
        modelBuilder.Entity<Pacient>().HasKey(p => p.IdPacient);
        modelBuilder.Entity<Medic>().HasKey(m => m.IdMedic);
        modelBuilder.Entity<Programare>().HasKey(p => p.IdProgramare);
        modelBuilder.Entity<Tratament>().HasKey(t => t.IdTratament);
        modelBuilder.Entity<Serviciu>().HasKey(s => s.IdServiciu);

        modelBuilder.Entity<Factura>()
            .HasOne(f => f.Programare)
            .WithOne(p => p.Factura)
            .HasForeignKey<Factura>(f => f.IdProgramare);

        // --- PASUL 5: REZOLVARE WARNINGS DECIMAL ---
        // Specificăm precizia pentru coloanele de bani (SQL Server are nevoie de asta)

        modelBuilder.Entity<Factura>()
            .Property(f => f.TotalPlata)
            .HasColumnType("decimal(18,2)");

        modelBuilder.Entity<Serviciu>()
            .Property(s => s.Pret)
            .HasColumnType("decimal(18,2)");

        modelBuilder.Entity<Programare>()
             .HasOne(p => p.Pacient)
             .WithMany()
             .HasForeignKey(p => p.IdPacient);

        modelBuilder.Entity<Programare>()
            .HasOne(p => p.Medic)
            .WithMany()
            .HasForeignKey(p => p.IdMedic);
    }
}